<?php
// File: admin/ajax-siteoptions-tests.php
if (!defined('ABSPATH')) exit;

function ssseo_ajax_test__respond($ok, $message, $last_option_key) {
    if ($last_option_key) update_option($last_option_key, $message);
    $payload = ['message'=>$message];
    $ok ? wp_send_json_success($payload) : wp_send_json_error($payload);
}
function ssseo_ajax_test__check_caps_and_nonce() {
    if (!current_user_can('edit_posts')) wp_send_json_error(['message'=>'Insufficient permissions.']);
    $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
    if (!wp_verify_nonce($nonce, 'ssseo_siteoptions_ajax')) wp_send_json_error(['message'=>'Invalid nonce. Reload and try again.']);
}

/** 1) Places API key */
add_action('wp_ajax_ssseo_test_places_key', function(){
    ssseo_ajax_test__check_caps_and_nonce();
    $key = isset($_POST['key']) ? sanitize_text_field(wp_unslash($_POST['key'])) : '';
    if ($key==='') ssseo_ajax_test__respond(false,'Enter an API key first.','ssseo_places_test_result');
    $url = add_query_arg(['place_id'=>'ChIJFFFFFFFFFFFFFFFFFFFFFake','fields'=>'name','key'=>$key],'https://maps.googleapis.com/maps/api/place/details/json');
    $r = wp_remote_get($url, ['timeout'=>15]); if (is_wp_error($r)) ssseo_ajax_test__respond(false,'Network error: '.$r->get_error_message(),'ssseo_places_test_result');
    $code = wp_remote_retrieve_response_code($r); $body = json_decode(wp_remote_retrieve_body($r), true);
    if ($code!==200 || !is_array($body)) ssseo_ajax_test__respond(false,'Unexpected response (HTTP '.$code.').','ssseo_places_test_result');
    $status = $body['status'] ?? 'UNKNOWN';
    if ($status==='REQUEST_DENIED') ssseo_ajax_test__respond(false,'Key rejected: '.($body['error_message']??$status),'ssseo_places_test_result');
    ssseo_ajax_test__respond(true,'Places API key looks valid (status: '.$status.').','ssseo_places_test_result');
});

/** 2) Places Place ID */
add_action('wp_ajax_ssseo_test_places_pid', function(){
    ssseo_ajax_test__check_caps_and_nonce();
    $key = isset($_POST['key']) ? sanitize_text_field(wp_unslash($_POST['key'])) : '';
    $pid = isset($_POST['place_id']) ? sanitize_text_field(wp_unslash($_POST['place_id'])) : '';
    if ($key==='') ssseo_ajax_test__respond(false,'Enter a Places API key first.','ssseo_places_pid_test_result');
    if ($pid==='') ssseo_ajax_test__respond(false,'Enter a Place ID to test.','ssseo_places_pid_test_result');
    $url = add_query_arg(['place_id'=>$pid,'fields'=>'name,formatted_address','key'=>$key],'https://maps.googleapis.com/maps/api/place/details/json');
    $r = wp_remote_get($url, ['timeout'=>15]); if (is_wp_error($r)) ssseo_ajax_test__respond(false,'Network error: '.$r->get_error_message(),'ssseo_places_pid_test_result');
    $code = wp_remote_retrieve_response_code($r); $body = json_decode(wp_remote_retrieve_body($r), true);
    if ($code!==200 || !is_array($body)) ssseo_ajax_test__respond(false,'Unexpected response (HTTP '.$code.').','ssseo_places_pid_test_result');
    if (($body['status'] ?? '')!=='OK') ssseo_ajax_test__respond(false,'Place ID failed: '.($body['error_message'] ?? $body['status']),'ssseo_places_pid_test_result');
    $name = $body['result']['name'] ?? '(name unavailable)'; $addr = $body['result']['formatted_address'] ?? '';
    ssseo_ajax_test__respond(true,'Place ID OK: '.$name.($addr?' — '.$addr:''),'ssseo_places_pid_test_result');
});

/** 3) Static Maps */
add_action('wp_ajax_ssseo_test_maps_key', function(){
    ssseo_ajax_test__check_caps_and_nonce();
    $key = isset($_POST['key']) ? sanitize_text_field(wp_unslash($_POST['key'])) : '';
    if ($key==='') ssseo_ajax_test__respond(false,'Enter a Static Maps API key first.','ssseo_maps_test_result');
    $url = add_query_arg(['center'=>'0,0','zoom'=>'1','size'=>'120x60','scale'=>'1','key'=>$key,'format'=>'png'], 'https://maps.googleapis.com/maps/api/staticmap');
    $r = wp_remote_get($url, ['timeout'=>15]); if (is_wp_error($r)) ssseo_ajax_test__respond(false,'Network error: '.$r->get_error_message(),'ssseo_maps_test_result');
    $code = wp_remote_retrieve_response_code($r); $ctype = wp_remote_retrieve_header($r,'content-type');
    if ($code!==200) ssseo_ajax_test__respond(false,'Static Maps responded HTTP '.$code.'.','ssseo_maps_test_result');
    if (stripos($ctype,'image/')===false) ssseo_ajax_test__respond(false,'Unexpected content-type ('.$ctype.'). Verify key and billing.','ssseo_maps_test_result');
    ssseo_ajax_test__respond(true,'Static Maps key looks valid (image returned).','ssseo_maps_test_result');
});

/** 4) OpenAI */
add_action('wp_ajax_ssseo_test_openai_key', function(){
    ssseo_ajax_test__check_caps_and_nonce();
    $key = isset($_POST['key']) ? trim((string) wp_unslash($_POST['key'])) : '';
    if ($key==='') ssseo_ajax_test__respond(false,'Enter an OpenAI API key first.','ssseo_openai_test_result');
    $r = wp_remote_get('https://api.openai.com/v1/models',[ 'timeout'=>20,'headers'=>['Authorization'=>'Bearer '.$key,'Content-Type'=>'application/json'] ]);
    if (is_wp_error($r)) ssseo_ajax_test__respond(false,'Network error: '.$r->get_error_message(),'ssseo_openai_test_result');
    $code = wp_remote_retrieve_response_code($r);
    if ($code===401) ssseo_ajax_test__respond(false,'OpenAI rejected the key (401 Unauthorized).','ssseo_openai_test_result');
    elseif ($code>=200 && $code<300) ssseo_ajax_test__respond(true,'OpenAI key looks valid (HTTP '.$code.').','ssseo_openai_test_result');
    else ssseo_ajax_test__respond(false,'Unexpected OpenAI response (HTTP '.$code.').','ssseo_openai_test_result');
});

/** 5) YouTube */
add_action('wp_ajax_ssseo_test_youtube_api', function(){
    ssseo_ajax_test__check_caps_and_nonce();
    $api_key = get_option('ssseo_youtube_api_key',''); $channel = get_option('ssseo_youtube_channel_id','');
    if ($api_key==='') ssseo_ajax_test__respond(false,'Save a YouTube API key first.','ssseo_youtube_test_result');
    if ($channel==='') ssseo_ajax_test__respond(false,'Save a YouTube Channel ID first.','ssseo_youtube_test_result');
    $url = add_query_arg(['part'=>'id','id'=>$channel,'key'=>$api_key],'https://www.googleapis.com/youtube/v3/channels');
    $r = wp_remote_get($url,['timeout'=>20]); if (is_wp_error($r)) ssseo_ajax_test__respond(false,'Network error: '.$r->get_error_message(),'ssseo_youtube_test_result');
    $code = wp_remote_retrieve_response_code($r); $body = json_decode(wp_remote_retrieve_body($r), true);
    if ($code!==200) { $msg = $body['error']['message'] ?? ('HTTP '.$code); ssseo_ajax_test__respond(false,'YouTube error: '.$msg,'ssseo_youtube_test_result'); }
    $items = isset($body['items']) && is_array($body['items']) ? count($body['items']) : 0;
    if ($items<1) ssseo_ajax_test__respond(false,'Channel not found. Check the Channel ID.','ssseo_youtube_test_result');
    ssseo_ajax_test__respond(true,'YouTube OK: Channel found.','ssseo_youtube_test_result');
});

/** 6) GSC client presence/shape */
add_action('wp_ajax_ssseo_test_gsc_client', function(){
    ssseo_ajax_test__check_caps_and_nonce();
    $cid = trim((string)get_option('ssseo_gsc_client_id',''));
    $sec = trim((string)get_option('ssseo_gsc_client_secret',''));
    $redir = trim((string)get_option('ssseo_gsc_redirect_uri',''));
    $missing = []; if ($cid==='') $missing[]='Client ID'; if ($sec==='') $missing[]='Client Secret'; if ($redir==='') $missing[]='Redirect URI';
    if ($missing) ssseo_ajax_test__respond(false,'Missing: '.implode(', ',$missing),'ssseo_gsc_test_result');
    if (strpos($cid,'.apps.googleusercontent.com')===false) ssseo_ajax_test__respond(false,'Client ID format looks suspicious (*.apps.googleusercontent.com).','ssseo_gsc_test_result');
    if (!wp_http_validate_url($redir)) ssseo_ajax_test__respond(false,'Redirect URI is not a valid URL.','ssseo_gsc_test_result');
    ssseo_ajax_test__respond(true,'GSC client appears correctly configured.','ssseo_gsc_test_result');
});
