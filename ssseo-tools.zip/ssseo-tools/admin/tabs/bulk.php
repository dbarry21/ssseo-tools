<?php
// File: admin/tabs/bulk.php
if (!defined('ABSPATH')) exit;

// Load shared data
$post_types = get_post_types(['public' => true], 'objects');

$posts_by_type = [];
foreach ($post_types as $pt) {
    $all_posts = get_posts([
        'post_type'      => $pt->name,
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'orderby'        => 'title',
        'order'          => 'ASC',
    ]);
    foreach ($all_posts as $p) {
        $posts_by_type[$pt->name][] = [
            'id'    => $p->ID,
            'title' => $p->post_title,
        ];
    }
}
$default_pt = array_key_first($posts_by_type);

// Additional data needed by some tabs
$top_services = get_posts([
    'post_type'      => 'service',
    'post_status'    => 'publish',
    'post_parent'    => 0,
    'orderby'        => 'title',
    'order'          => 'ASC',
    'posts_per_page' => -1,
]);

$top_service_areas = get_posts([
    'post_type'      => 'service_area',
    'post_status'    => 'publish',
    'post_parent'    => 0,
    'orderby'        => 'title',
    'order'          => 'ASC',
    'posts_per_page' => -1,
]);
?>

<div class="container mt-4">
  <h2>Bulk Operations</h2>

  <ul class="nav nav-tabs" id="ssseoBulkTabs" role="tablist">
  <li class="nav-item" role="presentation">
    <button class="nav-link active" id="yoast-tab" data-bs-toggle="tab" data-bs-target="#yoast" type="button" role="tab">Yoast Operations</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="services-tab" data-bs-toggle="tab" data-bs-target="#services" type="button" role="tab">Services Posts</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="youtube-tab" data-bs-toggle="tab" data-bs-target="#youtube" type="button" role="tab">YouTube Fix</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="canonical-tab" data-bs-toggle="tab" data-bs-target="#canonical" type="button" role="tab">Canonical</button>
  </li>
</ul>

<div class="tab-content border border-top-0 p-4">
  <div class="tab-pane fade show active" id="yoast" role="tabpanel" aria-labelledby="yoast-tab">
    <?php include __DIR__ . '/bulk/yoast.php'; ?>
  </div>
  <div class="tab-pane fade" id="services" role="tabpanel" aria-labelledby="services-tab">
    <?php include __DIR__ . '/bulk/services.php'; ?>
  </div>
  <div class="tab-pane fade" id="youtube" role="tabpanel" aria-labelledby="youtube-tab">
    <?php include __DIR__ . '/bulk/youtube.php'; ?>
  </div>
  <div class="tab-pane fade" id="canonical" role="tabpanel" aria-labelledby="canonical-tab">
    <?php include __DIR__ . '/bulk/canonical.php'; ?>
  </div>
</div>

</div>

<script>
  const ssseoPostsByType = <?= wp_json_encode($posts_by_type); ?>;
  const ssseoDefaultType = "<?= esc_js($default_pt); ?>";
</script>
